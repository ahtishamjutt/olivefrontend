import React from "react";
import clsx from "clsx";
import PropTypes from "prop-types";
import { makeStyles } from "@material-ui/styles";
import { Card, CardContent, Grid, Typography, Avatar } from "@material-ui/core";
import ArrowUpwardIcon from "@material-ui/icons/ArrowUpward";
import CardMedia from "@material-ui/core/CardMedia";
import Box from "@material-ui/core/Box";

const useStyles = makeStyles((theme) => ({
  root: {
    height: "100%",
  },
  content: {
    alignItems: "center",
    display: "flex",
  },
  title: {
    fontWeight: 700,
  },
  avatar: {
    backgroundColor: theme.palette.success.main,
    height: 56,
    width: 56,
  },
  icon: {
    height: 32,
    width: 32,
  },
  difference: {
    marginTop: theme.spacing(2),
    display: "flex",
    alignItems: "center",
  },
  media: {
    margin: "30px auto 0",
    width: "200px",
    height: 250,
    borderRadius: "4px",
    boxShadow: "0 10px 20px rgba(0, 0, 0, 0.19), 0 6px 6px rgba(0, 0, 0, 0.23)",
    zIndex: 1000,
  },
  differenceIcon: {
    color: theme.palette.success.dark,
  },
  differenceValue: {
    color: theme.palette.success.dark,
    marginRight: theme.spacing(1),
  },
}));

const TotalUsers = (props) => {
  const { className, ...rest } = props;

  const classes = useStyles();

  return (
    <Card {...rest} className={clsx(classes.root, className)}>
      <CardContent>
        <Grid container>
          <Grid item>
            <Typography
              className={classes.title}
              color="textSecondary"
              gutterBottom
              variant="body2"
            >
              What is Happening
            </Typography>
            <Typography variant="h4" gutterBottom>
              Feature Articles
            </Typography>
            <CardMedia
              className={classes.media}
              image="https://i.imgur.com/uQpulag.png"
              title="Contemplative Reptile"
            />
            <Box p={1} bgcolor="background.paper"></Box>
            <Typography variant="p">Corona Virus</Typography>
            <Box p={1} bgcolor="background.paper"></Box>
            <Typography variant="h5">How We are Fighting With It</Typography>
            <Box p={1} bgcolor="background.paper"></Box>
            <Typography variant="p">Today-6 Hours Ago</Typography>
            <Box p={1} bgcolor="background.paper"></Box>
            <Typography variant="p">
              The world has changed drastically overnight and...
            </Typography>
          </Grid>
        </Grid>
        <div className={classes.difference}>
          <ArrowUpwardIcon className={classes.differenceIcon} />
          <Typography className={classes.differenceValue} variant="body2">
            Corona Virus
          </Typography>
          <Typography>Training</Typography>

          <Typography className={classes.caption} variant="caption">
            How we are fighting with
          </Typography>
        </div>
        <Box p={4} bgcolor="background.paper"></Box>
        <Typography>What is COVID-19</Typography>
        <p>Today 12 hours ago</p>
      </CardContent>
    </Card>
  );
};

TotalUsers.propTypes = {
  className: PropTypes.string,
};

export default TotalUsers;
