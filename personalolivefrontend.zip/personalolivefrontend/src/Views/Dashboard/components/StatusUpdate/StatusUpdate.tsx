import React from "react";

import { makeStyles } from "@material-ui/styles";

import Card from "@material-ui/core/Card";
import CardActions from "@material-ui/core/CardActions";
import CardContent from "@material-ui/core/CardContent";
import CardMedia from "@material-ui/core/CardMedia";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import TextareaAutosize from "@material-ui/core/TextareaAutosize";
import Divider from "@material-ui/core/Divider";
import Avatar from "@material-ui/core/Avatar";
import Box from "@material-ui/core/Box";
import SendIcon from "@material-ui/icons/Send";

const useStyles = makeStyles((theme) => ({
  root: {
    minWidth: 275,
  },
  bullet: {
    display: "inline-block",
    margin: "0 2px",
    transform: "scale(0.8)",
  },
  title: {
    fontSize: 14,
  },
  pos: {
    marginBottom: 12,
  },
  media: {
    margin: "-70px auto 0",
    width: "100%",
    height: 270,
    borderRadius: "4px",
    boxShadow: "0 10px 20px rgba(0, 0, 0, 0.19), 0 6px 6px rgba(0, 0, 0, 0.23)",
    position: "relative",
    zIndex: 1000,
  },
  input: {
    width: "100%",
    border: "transparent",
    outlineColor: "transparent",
  },
  padding: {
    paddingBottom: 0,
  },
  button: {
    borderRadius: "50px",
    height: "47px",
  },
  send: {
    marginLeft: "200px !important",
  },
  avatar: {
    marginTop: "10px",
    marginLeft: "10px",
  },
  name: {
    marginLeft: "60px",
    marginTop: "-36px",
  },
  post: {
    margin: "15px",
  },
  comments: {
    marginLeft: "250px !important",
  },
}));

const StatusUpdate = (props: any) => {
  //   const { className, ...rest } = props;

  const classes = useStyles();
  console.log(props);
  return (
    <div>
      <Card className={classes.root}>
        <CardMedia
          className={classes.media}
          image="https://i.imgur.com/DWRo9Pd.jpg"
          title="Contemplative Reptile"
        />
        <CardContent className={classes.padding}>
          <Typography
            className={classes.title}
            color="textSecondary"
            gutterBottom
          ></Typography>
          <Typography className={classes.pos} color="textSecondary">
            <TextareaAutosize
              aria-label="minimum height"
              rowsMin={6}
              className={classes.input}
              placeholder="Share cool ideas and message with everyone"
            />
            <Divider />
          </Typography>
        </CardContent>
        <CardActions>
          <Button variant="contained" className={classes.button}>
            <Avatar alt="Travis Howard" src="https://i.imgur.com/umdKrtp.png" />
            <Box p={0.5}></Box>
            Photos
          </Button>
          <Button variant="contained" className={classes.button}>
            <Avatar alt="Travis Howard" src="https://i.imgur.com/WCEK6jE.jpg" />
            <Box p={0.5}></Box>
            Smilies
          </Button>
          <SendIcon className={classes.send} color="primary" />
        </CardActions>
      </Card>
      <Box p={6} bgcolor="background.paper"></Box>
      <CardMedia
        className={classes.media}
        image="https://i.imgur.com/lAJyVMG.jpg"
        title="Contemplative Reptile"
      />
      <Box p={3} bgcolor="background.paper"></Box>
      <Card className={classes.root}>
        <Avatar
          className={classes.avatar}
          alt="Travis Howard"
          src="https://www.manatt.com/Manatt/media/Media/Images/People/LeBlanc_John_New-2020-Bio-Template-730-x-730.jpg?ext=.jpg"
        />
        <Typography className={classes.name}>Jon wick</Typography>
        <Box p={1}></Box>
        <Typography className={classes.post}>
          You can catch COVID-19, no matter how sunny or hot the weather is.
          Countries with hot weather have reported cases of COVID-19. To protect
          yourself, make sure you clean your hands frequently and thoroughly and
          avoid touching your eyes, mouth, and nose.
        </Typography>
        <Typography className={classes.post}>
          You can catch COVID-19, no matter how sunny or hot the weather is.
          Countries with hot weather have reported cases of COVID-19.
        </Typography>
        <CardMedia
          className={classes.media}
          image="https://eandt.theiet.org/media/10817/dreamstime_l_174291761.jpg?anchor=center&mode=crop&width=640&height=480&rnd=132278099800000000"
          title="Contemplative Reptile"
        />
        <CardContent className={classes.padding}>
          <Typography
            className={classes.title}
            color="textSecondary"
            gutterBottom
          ></Typography>
          <Typography className={classes.pos} color="textSecondary">
            <Divider />
          </Typography>
        </CardContent>
        <CardActions>
          <Avatar
            className={classes.avatar}
            alt="Travis Howard"
            src="https://pngimg.com/uploads/like/like_PNG14.png"
          />
          <Avatar
            className={classes.avatar}
            alt="Travis Howard"
            src="https://lh3.googleusercontent.com/proxy/9CAo_Mv26xUzhklnVTDyWWqDEKbvJLnSiIu0iPTo0Myr6vdMKCnQCfjjq8by1GNpQMQ8LWanC9L6uziJSi0XYzn7NTnxx0A"
          />
          <Avatar
            className={classes.avatar}
            alt="Travis Howard"
            src="https://cdn.imgbin.com/3/7/13/imgbin-facebook-computer-icons-anger-angry-emoji-angry-emoticon-qdDqUAtgwSEPkKTG4MfRudQmb.jpg"
          />
          <a className={classes.comments} href="#">
            Comments
          </a>
        </CardActions>
      </Card>
    </div>
  );
};

export default StatusUpdate;
