import React, { useState } from "react";
import { Link as RouterLink } from "react-router-dom";
import clsx from "clsx";
import PropTypes from "prop-types";
import { makeStyles } from "@material-ui/styles";
import ViewWeekIcon from "@material-ui/icons/ViewWeek";
import {
  AppBar,
  Toolbar,
  Badge,
  Hidden,
  IconButton,
  Typography,
} from "@material-ui/core";
import MenuIcon from "@material-ui/icons/Menu";
import NotificationsIcon from "@material-ui/icons/NotificationsOutlined";
import InputIcon from "@material-ui/icons/Input";
import AccountCircleIcon from "@material-ui/icons/AccountCircle";
import SettingsIcon from "@material-ui/icons/Settings";
import Box from "@material-ui/core/Box";
import GroupIcon from "@material-ui/icons/Group";
import VisibilityIcon from "@material-ui/icons/Visibility";
import MapIcon from "@material-ui/icons/Map";
import DashboardIcon from "@material-ui/icons/Dashboard";
import AssessmentIcon from "@material-ui/icons/Assessment";
import HomeIcon from "@material-ui/icons/Home";

const useStyles = makeStyles((theme) => ({
  root: {
    boxShadow: "none",
  },
  flexGrow: {
    flexGrow: 1,
  },
  signOutButton: {
    marginLeft: theme.spacing(1),
  },
  resize: {
    fontSize: "15px",
  },
  margin: {
    fontSize: "15px",
    marginRight: "13%",
  },
}));

const Topbar = (props) => {
  const { className, onSidebarOpen, ...rest } = props;

  const classes = useStyles();

  const [notifications] = useState([]);

  return (
    <AppBar {...rest} className={clsx(classes.root, className)}>
      <Toolbar>
        <ViewWeekIcon />
        <Box p={0.5}></Box>
        <RouterLink to="/">
          <img alt="Logo" src="https://i.imgur.com/Z0UoFw4.png" />
        </RouterLink>

        <div className={classes.flexGrow} />
        <IconButton className={classes.resize} color="inherit">
          <HomeIcon />
          Front Page
        </IconButton>
        <IconButton className={classes.resize} color="inherit">
          <AssessmentIcon />
          Report
        </IconButton>
        <IconButton className={classes.resize} color="inherit">
          <DashboardIcon />
          Dashboard
        </IconButton>
        <IconButton className={classes.resize} color="inherit">
          <MapIcon />
          Map
        </IconButton>
        <IconButton className={classes.resize} color="inherit">
          <VisibilityIcon />
          Show
        </IconButton>
        <IconButton className={classes.margin} color="inherit">
          <GroupIcon />
          Org Chart
        </IconButton>
        <Hidden mdDown>
          <IconButton color="inherit">
            <Badge
              badgeContent={notifications.length}
              color="primary"
              variant="dot"
            >
              <NotificationsIcon />
            </Badge>
          </IconButton>

          <IconButton color="inherit">
            <AccountCircleIcon />
          </IconButton>

          <IconButton color="inherit">
            <SettingsIcon />
          </IconButton>
          <IconButton className={classes.signOutButton} color="inherit">
            <InputIcon />
          </IconButton>
        </Hidden>
        <Hidden lgUp>
          <IconButton color="inherit" onClick={onSidebarOpen}>
            <MenuIcon />
          </IconButton>
        </Hidden>
      </Toolbar>
    </AppBar>
  );
};

Topbar.propTypes = {
  className: PropTypes.string,
  onSidebarOpen: PropTypes.func,
};

export default Topbar;
