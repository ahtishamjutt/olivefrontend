/// <reference types="react-scripts" />
declare module 'react-activity-feed';
